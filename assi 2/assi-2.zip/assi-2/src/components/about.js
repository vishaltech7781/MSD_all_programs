import React, { Component } from "react";
import styles from "./about.module.css";

class About extends Component {
  render() {
    return (
      <div className={styles.box}>
        <h2>About Component</h2>
      </div>
    );
  }
}

export default About;