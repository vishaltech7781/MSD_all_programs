import React, { Component } from "react";

class Contact extends Component {
  render() {

    const myStyle = {
      color: "white",
      backgroundColor: "green",
      padding: "20px",
      textAlign: "center"
    };

    return (
      <div style={myStyle}>
        <h2>Contact Component</h2>
      </div>
    );
  }
}

export default Contact;