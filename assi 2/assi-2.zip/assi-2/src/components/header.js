import React, { Component } from "react";
import "./header.css";

class Header extends Component {
  render() {
    return (
      <div className="header">
        <h1>Welcome to React</h1>
      </div>
    );
  }
}

export default Header;